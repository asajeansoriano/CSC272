import java.io.File;
import java.util.*;

public class test {

    public static void main(String[] args) {
        System.out.println(new File("penis.txt").getAbsolutePath());
    }
    
}
